package org.example.proideas.Controller;

import java.util.List;

import org.example.proideas.Entity.UserEntity;
import org.example.proideas.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;



@RestController
public class UserController {

    @Autowired
    private UserService userService;

    // Create User
    @PostMapping("/save")
    public UserEntity saveUser(@RequestBody UserEntity user) {
        return userService.saveUser(user);
    }

    // Get All Users
    @GetMapping("/getall")
    public List<UserEntity> getAllUsers() {
        return userService.getAllUsers();
    }

    // Get User By Id
    @GetMapping("/getone/{id}")
    public UserEntity getUserById(@PathVariable long id) {
        return userService.getUserById(id);
    }

    // Update User
    @PutMapping("/edit")
    public UserEntity updateUser(@RequestBody UserEntity user) {
        return userService.updateUser(user);
    }

    // Delete User
    @DeleteMapping("/delete/{id}")
    public String deleteUser(@PathVariable long id) {
        return userService.deleteUser(id);
    }
}
